
if abiquo_installed?

puts "Abiquo Components:".bold.ljust(40) + (abiquo_components_installed).inspect

end
