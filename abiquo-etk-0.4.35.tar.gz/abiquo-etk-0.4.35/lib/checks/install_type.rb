#
# Helpers  
#
if abiquo_installed?

puts "Abiquo Install:".bold.ljust(40) + detect_install_type.to_s.upcase.bold.blue

end
