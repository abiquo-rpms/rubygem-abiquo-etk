if not abiquo_installed?
  puts "Abiquo Installation Not Found.".bold.red
end

